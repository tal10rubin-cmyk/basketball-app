// Weekly Basketball App – Base44 MVP Spec
// Framework: React (via Base44), Tailwind CSS, Google Calendar API

import { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function WeeklyBasketballApp() {
  const [isRegistered, setIsRegistered] = useState(false);
  const [hasPaid, setHasPaid] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [hasDebt, setHasDebt] = useState(true); // סימולציה לחוב פתוח
  const [whatBringing, setWhatBringing] = useState({ ball: false, pump: false, key: false });
  const [isAdmin, setIsAdmin] = useState(true); // סימולציה למשתמש מנהל
  const [showAdminTab, setShowAdminTab] = useState(false);
  const [debts, setDebts] = useState([
    { name: 'איתן טל', date: '28/7', amount: 45, status: 'פתוח' },
    { name: 'בן עמרם', date: '21/7', amount: 45, status: 'פתוח' }
  ]);

  const handleRegister = () => {
    setIsRegistered(true);
    // Trigger calendar invite logic here (Google Calendar API)
  };

  const handlePay = () => {
    setHasPaid(true);
    setHasDebt(false); // תשלום סוגר חוב
    const updatedDebts = debts.map((debt) =>
      debt.name === 'שם המשתמש שלך' && debt.status === 'פתוח'
        ? { ...debt, status: 'סגור' }
        : debt
    );
    setDebts(updatedDebts);
  };

  const handleSubscribe = () => {
    setIsSubscribed(true);
    setHasDebt(false); // מנוי סוגר חוב
    const updatedDebts = debts.map((debt) =>
      debt.name === 'שם המשתמש שלך' && debt.status === 'פתוח'
        ? { ...debt, status: 'סגור' }
        : debt
    );
    setDebts(updatedDebts);
  };

  const handleDebtClear = (index) => {
    const updatedDebts = [...debts];
    updatedDebts[index].status = 'סגור';
    setDebts(updatedDebts);
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <Card className="mb-4">
        <CardContent>
          <h2 className="text-xl font-bold">המשחק הקרוב - יום ראשון</h2>
          <p>שלום ציון המלכה 65, תל אביב</p>
          <p>שעה: 20:00–22:00</p>
          <p>משתתפים: 9/12</p>

          {hasDebt ? (
            <p className="text-red-600 font-semibold">❌ לא ניתן להירשם – יש לך חוב פתוח</p>
          ) : !isRegistered ? (
            <Button className="mt-2" onClick={handleRegister}>אני בא למשחק הקרוב</Button>
          ) : (
            <p className="text-green-600">✔ אתה רשום</p>
          )}

          {!hasPaid && !isSubscribed && !hasDebt && (
            <Button className="mt-2" onClick={handlePay}>שילמתי 45 ש"ח בפייבוקס</Button>
          )}
          {hasPaid && <p className="text-green-600">✔ תשלום סומן</p>}

          {isSubscribed && <p className="text-blue-600">✔ אתה מנוי לחודש זה</p>}

          <div className="mt-4">
            <p className="font-semibold">מה אתה מביא:</p>
            <label className="block"><input type="checkbox" onChange={() => setWhatBringing(prev => ({ ...prev, ball: !prev.ball }))}/> 🏀 כדור</label>
            <label className="block"><input type="checkbox" onChange={() => setWhatBringing(prev => ({ ...prev, pump: !prev.pump }))}/> 💨 משאבה</label>
            <label className="block"><input type="checkbox" onChange={() => setWhatBringing(prev => ({ ...prev, key: !prev.key }))}/> 🔑 מפתח לאולם</label>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-4">
        <CardContent>
          <Button onClick={handleSubscribe}>קנה מנוי חודשי – 180 ש"ח</Button>
        </CardContent>
      </Card>

      {isAdmin && (
        <Card>
          <CardContent>
            <Button variant="outline" onClick={() => setShowAdminTab(!showAdminTab)}>
              {showAdminTab ? 'סגור טאב ניהול' : 'כניסה לטאב מנהל'}
            </Button>

            {showAdminTab && (
              <div className="mt-4 text-right">
                <h3 className="text-lg font-bold mb-2">רשימת משתתפים</h3>
                <ul className="list-disc pr-5">
                  <li>עידו ברקאי – ✔ שילם – 🏀 כדור, 🔑 מפתח</li>
                  <li>ליאב כהן – ❌ לא שילם – 💨 משאבה</li>
                </ul>

                <h3 className="text-lg font-bold mt-6 mb-2">דוח חובות</h3>
                <table className="w-full text-right border">
                  <thead>
                    <tr className="border-b">
                      <th className="p-2">שם</th>
                      <th className="p-2">תאריך משחק</th>
                      <th className="p-2">סכום</th>
                      <th className="p-2">סטטוס</th>
                      <th className="p-2">פעולה</th>
                    </tr>
                  </thead>
                  <tbody>
                    {debts.map((debt, idx) => (
                      <tr key={idx} className="border-b">
                        <td className="p-2">{debt.name}</td>
                        <td className="p-2">{debt.date}</td>
                        <td className="p-2">₪{debt.amount}</td>
                        <td className="p-2 text-red-600">{debt.status}</td>
                        <td className="p-2">
                          {debt.status === 'פתוח' && (
                            <Button size="sm" onClick={() => handleDebtClear(idx)}>סגור חוב</Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
